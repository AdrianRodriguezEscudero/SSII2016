%Definici�n_de_operadores(if-then)

:-op(800,fx,if).
:-op(700,xfx,then).
:-op(200,xfy,and).

%Encadenamiento_de_las_reglas

is_true(P):-fact(P).
is_true(P):-if Condition then P,is_true(Condition).
is_true(P1 and P2):-is_true(P1),is_true(P2).
is_true(P1 or P2):-is_true(P1);is_true(P2).
            
is_true(P1 and P2 and P3):-is_true(P1),is_true(P2),is_true(P3).

%Reglas

if a and b then c.
if d and e and f then g.
if h and i then j.
if c and g then k.
if g and j then l.
if k and l then m.

% G= verdadero, L= falso, J Variable del objeto

%Base_de_Hechos

fact(g).
fact(c).