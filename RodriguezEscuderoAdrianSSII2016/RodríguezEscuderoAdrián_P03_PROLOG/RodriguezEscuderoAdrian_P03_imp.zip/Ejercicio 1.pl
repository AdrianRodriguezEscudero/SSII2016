%Base_de_Hechos

hijo(enrique,ana).
hijo(enrique,oscar).
hija(eva,oscar).
hija(eva,ana).
hija(isabel,oscar).
hija(isabel,ana).
hijo(oscar,carmen).
hijo(oscar,javier).
hijo(antonio,maria).
hijo(antonio,francisco).
hija(maria,carmen).
hija(maria,javier).

%Reglas

descendiente(X,Y):-hijo(X,Y);hija(X,Y).