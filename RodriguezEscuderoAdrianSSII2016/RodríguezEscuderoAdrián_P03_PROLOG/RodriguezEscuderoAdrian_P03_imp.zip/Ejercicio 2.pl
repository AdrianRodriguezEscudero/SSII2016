%Programa_en_Prolog

inicio:-accion(estado(cinco,seis,siete,cuatro,cero,ocho,tres,dos,uno),estado(uno,dos,tres,ocho,cero,cuatro,siete,seis,cinco)).

accion(Inicio,Objetivo):-plan(Inicio,Objetivo,[Inicio],Camino),nl,write('Solucion :'),nl,write(Camino).

plan(Inicio,Objetivo,Visitados,Camino):-ir(Inicio,Siguiente),seguro(Siguiente),\+ member(Siguiente,Visitados),plan(Siguiente,Objetivo,[Siguiente|Visitados],Camino).

plan(Objetivo,Objetivo,Camino,Camino).

%Acciones_del_problema

ir(estado(cero,Y,E,R,T,M,U,I,O),estado(Y,cero,E,R,T,M,U,I,O)):-derecha(cero).
ir(estado(X,cero,Y,R,T,M,U,I,O),estado(X,Y,cero,R,T,M,U,I,O)):-derecha(cero).
ir(estado(X,Y,Z,cero,T,M,U,I,O),estado(X,Y,Z,T,cero,M,U,I,O)):-derecha(cero).
ir(estado(X,Y,Z,T,cero,M,U,I,O),estado(X,Y,Z,T,M,cero,U,I,O)):-derecha(cero).
ir(estado(X,Y,Z,T,M,U,cero,I,O),estado(X,Y,Z,T,M,U,I,cero,O)):-derecha(cero).
ir(estado(X,Y,Z,T,M,U,I,cero,O),estado(X,Y,Z,T,M,U,I,O,cero)):-derecha(cero).

derecha(cero).

seguro(estado(B,W,Z,K)):-cruzar(W,Z),cruzar(Z,K).
seguro(estado(B,B,B,K)).
seguro(estado(B,W,B,B)).