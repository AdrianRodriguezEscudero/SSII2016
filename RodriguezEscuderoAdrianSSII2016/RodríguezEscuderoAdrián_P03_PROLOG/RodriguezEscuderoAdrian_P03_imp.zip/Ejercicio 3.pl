%Base_de_Hechos

inicio:-accion(estado(derecha,sucio,sucio),estado(izquierda,limpio,limpio)).

accion(Inicio,Objetivo):-plan(Inicio,Objetivo,[Inicio],Camino),nl,write('Solucion: '),nl,write(Camino).

plan(Inicio,Objetivo,Visitados,Camino):-ir(Inicio,Siguiente),\+ member(Siguiente,Visitados),    
plan(Siguiente,Objetivo,[Siguiente|Visitados],Camino).
plan(Objetivo,Objetivo,Camino,Camino).

%Posibles_acciones

ir(estado(PosicionA,A,X),estado(Posicion,B,X)):-limpiar_izquierda(PosicionA,A,B).   
ir(estado(PosicionA,X,A),estado(Posicion,X,B)):-limpiar_derecha(PosicionA,A,B).     
ir(estado(PosicionA,X,X),estado(PosicionB,X,X)):-desplazar(PosicionA,PosicionB).    

limpiar_izquierda(izquierda,sucio,limpio).
limpiar_derecha(derecha,sucio,limpio).
desplazar(izquierda,derecha).
desplazar(derecha,izquierda).